/* LOTTO LAB 6/45 v1.9 — browser-first generator, statistics, saved numbers. No backtest UI. */
(() => {
'use strict';
const $ = id => document.getElementById(id);
const nf = n => Number(n).toLocaleString('ko-KR');
const money = n => `${nf(Math.round(n))}원`;
const defaults = {carry:12, lastEnd:3, endPairs:10, sum:12, odd:12, gaps:10, high:8, hot:8};
const weightLabels = {carry:'전주 이월 0~1개',lastEnd:'전주와 같은 끝수 포함',endPairs:'동일 끝수 1쌍',sum:'번호 합계',odd:'홀수 개수',gaps:'인접 간격 1~3',high:'41~45 번호 개수',hot:'최근 100회 TOP 10 포함'};
const dataURL = 'https://smok95.github.io/lotto/results/all.json';
const fallbackURL = 'https://papaya5rhw1984.github.io/lotto-data/all.json';
const scorePatternSpecs = [
 {id:'carry',name:'전주 번호 이월',description:'직전 당첨번호 0~1개 포함'},
 {id:'lastEnd',name:'전주와 같은 끝수',description:'직전 회차와 일의 자리가 같은 번호'},
 {id:'endPairs',name:'동일 끝수 쌍',description:'동일 끝수 0·1·2쌍 구성'},
 {id:'sum',name:'번호 합계',description:'100~180 및 120~159 구간 평가'},
 {id:'odd',name:'홀짝 비율',description:'홀수 2·3·4개 중심'},
 {id:'gaps',name:'번호 간격 1~3',description:'정렬된 번호 사이 가까운 간격'},
 {id:'high',name:'41~45 번호 개수',description:'높은 번호 구간 포함 개수'},
 {id:'hot',name:'최근 100회 TOP10',description:'최근 출현 상위 번호의 포함 개수'}
];
const extraPatternSpecs = [
 {id:'preferPrevious',name:'전주 번호 0~1개 선호',description:'전주 이월을 추가로 우선',enabled:true},
 {id:'preferNeighbors',name:'전주 ±1~2 인접수 1~2개',description:'전주 번호 주변의 다른 번호 1~2개',enabled:true},
 {id:'preferNoRuns',name:'연속번호 0~1쌍',description:'연속번호가 많지 않은 조합 선호',enabled:true},
 {id:'preferMid',name:'최근 6개월 3~4회 출현',description:'중간 빈도 번호 1~3개 선호',enabled:true},
 {id:'coreLimit',name:'이번 주 핵심번호 포함',description:'아래에서 1~2개 또는 2~3개 선택',enabled:false},
 {id:'preferPrev2',name:'전전주 당첨번호 0~2개',description:'2주 전 번호와의 중복 개수',enabled:false},
 {id:'preferAc',name:'AC값 7~10',description:'번호 간 차이의 다양성',enabled:false},
 {id:'preferPrime',name:'소수 1~3개',description:'2·3·5·7·11 등 소수 개수',enabled:false},
 {id:'preferColor',name:'같은 색 4개 이상 피하기',description:'특정 10번대 구간의 몰림 방지',enabled:false},
 {id:'preferOverdue',name:'100회 고빈도·최근 미출현',description:'최근 10회 미출현 TOP10 번호',enabled:false},
 {id:'preferPairs',name:'동반 출현 번호 쌍',description:'최근 100회에서 자주 함께 등장한 쌍',enabled:false},
 {id:'preferHotCold',name:'핫수·콜드수 혼합',description:'최근 10회 출현 구간을 나누어 참고',enabled:false}
];
const defaultPatternToggles = Object.fromEntries([...scorePatternSpecs.map(x=>[x.id,true]),...extraPatternSpecs.map(x=>[x.id,x.enabled])]);
const keys = {draws:'lottolab.draws.v1', saved:'lottolab.saved.v1', weights:'lottolab.weights.v1',patterns:'lottolab.patterns.v1',sync:'lottolab.sync.last'};
const previousGenerationKey='lottolab.genprevious.v2'; // stores only prior generated numbers, not sensitive data
const AUTO_REFRESH_MS = 6 * 60 * 60 * 1000; // foreground-open check, no background scheduler
function readStore(k, backup) { try { const x=localStorage.getItem(k); return x?JSON.parse(x):backup; } catch(_) {return backup;} }
function writeStore(k,data){ try {localStorage.setItem(k,JSON.stringify(data));return true;} catch(e){return false;} }
function normalizeDraw(d) {
 const no=Number(d.no??d.draw_no??d.round??d.drawNo);
 const nums=(d.numbers??d.nums??[]).map(Number).sort((a,b)=>a-b);
 const bonus=Number(d.bonus??d.bonus_no??d.bonusNo);
 if(!Number.isInteger(no)||no<1||nums.length!==6||new Set(nums).size!==6||nums.some(n=>!Number.isInteger(n)||n<1||n>45)||!Number.isInteger(bonus)||bonus<1||bonus>45||nums.includes(bonus)) return null;
 const raw=Array.isArray(d.prizes)?d.prizes:(d.divisions??d.ranks??[]).map(v=>v.prize??v.prizePerWinner??null);
 const prizes=Array.from({length:5},(_,i)=>raw[i]===null||raw[i]===undefined?null:Number(raw[i]));
 prizes[3]=prizes[3]??50000; prizes[4]=prizes[4]??5000;
 const date=String(d.date??'').slice(0,10);
 return {no,date:/^\d{4}-\d\d-\d\d$/.test(date)?date:'',numbers:nums,bonus,prizes};
}
function normalizeList(payload) {
 let a=Array.isArray(payload)?payload:(payload.data??payload.results??payload.draws);
 if(!Array.isArray(a)) throw new Error('당첨번호 JSON 배열을 찾을 수 없습니다.');
 const m=new Map();for(const r of a){let n=normalizeDraw(r);if(n)m.set(n.no,n);}
 const list=Array.from(m.values()).sort((a,b)=>a.no-b.no);
 if(list.length===0)throw new Error('유효한 당첨번호가 없습니다.');
 return list;
}
function mergeDraws(oldList,newList){let m=new Map(oldList.map(d=>[d.no,d]));for(const d of newList){const prev=m.get(d.no);if(!prev||d.prizes.filter(x=>x!==null).length>=prev.prizes.filter(x=>x!==null).length)m.set(d.no,d);}return Array.from(m.values()).sort((a,b)=>a.no-b.no);}
let cached=[];try {cached=normalizeList(readStore(keys.draws,[]));}catch(_){}
let rows=mergeDraws(window.LOTTO_SEED.map(normalizeDraw).filter(Boolean),cached);
const state={rows,saved:readStore(keys.saved,[]),generated:[],selectedGenerated:new Set(),previousGenerated:readStore(previousGenerationKey,[]),weights:{...defaults,...readStore(keys.weights,{})},patterns:{...defaultPatternToggles,...readStore(keys.patterns,{})},activeView:'home',dataMode:cached.length>28?'저장된 전체 기록':'기본 내장 데이터',busy:false,syncing:false,syncError:'',statsRange:'26',probRange:'26',installPrompt:null,settingsDirty:false};
for(const key of Object.keys(defaults)) {let n=Number(state.weights[key]);state.weights[key]=Number.isFinite(n)?Math.max(0,Math.min(30,n)):defaults[key];}
function latest(){return state.rows[state.rows.length-1];}
function haveWholeHistory(){return state.rows[0]?.no===1 && state.rows.every((r,i)=>r.no===i+1);}
function tail(draws,num){return num==='all'?draws.slice():draws.slice(-Number(num));}
function countFrequency(draws){const c=Array(46).fill(0);for(const d of draws)for(const n of d.numbers)c[n]++;return c;}
function topNumbers(freq,k=11){return Array.from({length:45},(_,i)=>i+1).sort((a,b)=>freq[b]-freq[a]||a-b).slice(0,k);}
// Eight UNIQUE descriptive picks, always ONE composite method: 3 recent strength,
// 2 historical frequency, 2 historical-hot recently-unseen, and 1 previous-draw associate.
// All calculations use only draws passed in `hist`; not a probability predictor.
const CORE_GROUPS=[
 {key:'recent',label:'최근 강세',count:3,subtitle:'최근 26회와 100회 빈도 함께 반영'},
 {key:'alltime',label:'누적 강세',count:2,subtitle:'분석 가능한 전체 기간의 출현 횟수'},
 {key:'overdue',label:'최근 미출현',count:2,subtitle:'최근 100회 강세 중 최근 10회 미등장 우선'},
 {key:'neighbor',label:'전주 연관',count:1,subtitle:'전주 ±1·2와 과거 동반 출현'}
];
function weeklyCore(hist){
 const f10=countFrequency(tail(hist,10));
 const f26=countFrequency(tail(hist,26));
 const f100=countFrequency(tail(hist,100));
 const fall=countFrequency(hist);
 const order26=topNumbers(f26,45),order100=topNumbers(f100,45),orderAll=topNumbers(fall,45);
 const ranks=order=>new Map(order.map((n,i)=>[n,i+1]));
 const r26=ranks(order26),r100=ranks(order100),rAll=ranks(orderAll);
 const seen10=new Set(tail(hist,10).flatMap(d=>d.numbers));
 const prev=hist.at(-1)?.numbers||[];
 const near=neighborsFrom(prev);
 const used=new Set(),groups=[];
 const scoreRecent=n=>.55*(46-r26.get(n))+.45*(46-r100.get(n));
 const pick=(key,rankFn,filterFn=()=>true)=>{
   const spec=CORE_GROUPS.find(g=>g.key===key);
   const options=Array.from({length:45},(_,i)=>i+1).filter(n=>!used.has(n));
   const ordered=options.filter(filterFn).sort((a,b)=>rankFn(b)-rankFn(a)||a-b);
   // If a strict candidate group is empty, fall back rather than duplicate numbers.
   const fallback=options.filter(n=>!ordered.includes(n)).sort((a,b)=>rankFn(b)-rankFn(a)||a-b);
   const numbers=[...ordered,...fallback].slice(0,spec.count);
   numbers.forEach(n=>used.add(n));
   groups.push({...spec,numbers});
 };
 pick('recent',scoreRecent);
 pick('alltime',n=>46-rAll.get(n));
 const lastSeenGap=n=>{
   for(let i=hist.length-1;i>=0;i--)if(hist[i].numbers.includes(n))return hist.length-1-i;
   return hist.length; // cannot infer earlier unobserved draws
 };
 // Prioritise qualifying 100-round high-frequency numbers absent from last 10.
 pick('overdue',n=>100*(46-r100.get(n))+Math.min(25,lastSeenGap(n)),n=>!seen10.has(n));
 const pairHistory=tail(hist,100);
 const assoc=n=>{
   let paired=0;
   for(const d of pairHistory)if(d.numbers.includes(n)){
      paired+=d.numbers.filter(x=>prev.includes(x)&&x!==n).length;
   }
   const nearest=prev.length?Math.min(...prev.map(x=>Math.abs(n-x))):50;
   return paired*8+f26[n]*.3+f100[n]*.05+(nearest===1?3:nearest===2?1.5:0);
 };
 pick('neighbor',assoc,n=>near.has(n));
 const items=groups.flatMap(g=>g.numbers.map(n=>({number:n,group:g.key,label:g.label,
   recent26:f26[n],recent100:f100[n],all:fall[n],recent10:f10[n],gap:lastSeenGap(n)})));
 return {round:(hist.at(-1)?.no||0)+1,items,groups,counts:{recent26:Math.min(26,hist.length),recent100:Math.min(100,hist.length),whole:hist.length},fullHistory:hist[0]?.no===1};
}
function coreNumbers(hist){return weeklyCore(hist).items.map(x=>x.number);}
function renderCore(){
 const core=weeklyCore(state.rows),nums=core.items.map(x=>x.number);
 const limited=core.counts.recent100<100||!core.fullHistory;
 const warning=limited?`<p class="field-help warning-note">현재 ${core.counts.whole}개 회차만 보유 중이에요. 최근 100회/전체 누적 기준은 확보한 자료 범위에서 계산했으며, 전체 당첨기록 갱신 시 자동 변경됩니다.</p>`:'';
 const groups=core.groups.map(g=>`<div class="core-group-row"><div class="core-group-text"><strong>${g.label} <small>${g.count}개</small></strong><small>${g.subtitle}</small></div><div class="balls">${ballsHtml(g.numbers,'small')}</div></div>`).join('');
 $('homeCore').innerHTML=`<div class="core-header"><strong>제${core.round}회 핵심 후보 8개</strong><span class="pill">복합 패턴 · 한 가지 기준</span></div><div class="core-main-balls balls">${ballsHtml(nums,'small')}</div><p class="field-help">최근 강세 3 · 누적 강세 2 · 최근 미출현 2 · 전주 연관 1 (번호 중복 없음)</p>${groups}${warning}<p class="field-help">각 그룹 내 상위 빈도와 인접 조건을 조합한 <b>선호지수</b>이며, 다음 추첨 당첨 확률이 올라가는 것은 아닙니다.</p>`;
 $('generatorCore').innerHTML=`<div class="balls">${ballsHtml(nums,'small')}</div><p class="field-help">복합 패턴형 8개: 최근 강세 3 · 누적 2 · 미출현 2 · 전주 연관 1. 기본값에서는 조합에 강제하지 않아요.</p>${limited?'<p class="field-help warning-note">전체 기록 갱신 후 정확한 장기 비교가 가능해요.</p>':''}`;
}
function renderSyncStatus(){
 let t=0;try{t=Number(localStorage.getItem(keys.sync))||0;}catch(_){}
 const when=t?new Date(t).toLocaleString('ko-KR',{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'}):'자동 갱신 기록 없음';
 const label=state.syncing?'온라인 당첨번호 확인 중…':state.syncError?'갱신 실패 · 내장/저장 데이터로 분석 중':'마지막 갱신: '+when;
 const last=latest();const lastTime=last?.date?new Date(last.date+'T21:00:00+09:00').getTime():0;
 const outdated=lastTime && Date.now()-lastTime>9*86400000;
 const note=state.syncError?`<small>${state.syncError}</small>`:outdated?'<small>보유한 마지막 당첨일이 9일 이상 지났어요. 서버 갱신을 확인해주세요.</small>':'<small>매번 앱 실행·복귀 시 최신 여부를 점검하고 6시간마다 다시 확인</small>';
 $('homeSync').innerHTML=`<div class="sync-row"><span><strong>데이터: 제${last?.no||'?'}회까지</strong><br><small>${label}</small></span><button class="small-button" id="syncNow" ${state.syncing?'disabled':''}>${state.syncing?'갱신 중':'지금 갱신'}</button></div>${note}`;
 $('syncNow')?.addEventListener('click',()=>refreshData(false));
}
function ballClass(n){return n<=10?'yellow':n<=20?'blue':n<=30?'red':n<=40?'gray':'green';}
function ballsHtml(nums,size='small'){return nums.map(n=>`<span class="ball ${size} ${ballClass(n)}" aria-label="${n}번">${n}</span>`).join('');}
function numsText(nums){return nums.join(', ');}
function sum(a){return a.reduce((acc,n)=>acc+n,0);}
function intersection(a,b){const q=new Set(b);return a.filter(n=>q.has(n));}
function sameEndPairCount(c){const groups=Array(10).fill(0);for(let n of c)groups[n%10]++;return groups.reduce((x,v)=>x+v*(v-1)/2,0);}
function acValue(c){let dif=new Set();for(let i=0;i<6;i++)for(let j=i+1;j<6;j++)dif.add(c[j]-c[i]);return dif.size-5;}
function consecutiveCount(c){let k=0;for(let i=1;i<c.length;i++)if(c[i]-c[i-1]===1)k++;return k;}
function nearGapCount(c){let k=0;for(let i=1;i<c.length;i++)if(c[i]-c[i-1]<=3)k++;return k;}
function neighborsFrom(last){const s=new Set();for(let n of last)for(let delta of [-2,-1,1,2])if(n+delta>=1&&n+delta<=45)s.add(n+delta);for(let n of last)s.delete(n);return s;}
function buildContext(hist){
 const prev=hist.length?hist[hist.length-1].numbers:[];
 const prev2=hist.length>=2?hist[hist.length-2].numbers:[];
 const f100=countFrequency(tail(hist,100)),f26=countFrequency(tail(hist,26));
 const recent=tail(hist,10),halfA=recent.slice(-5),halfB=recent.slice(-10,-5);
 const setA=new Set(halfA.flatMap(d=>d.numbers)),setB=new Set(halfB.flatMap(d=>d.numbers));
 const hotNums=new Set([...setA].filter(n=>setB.has(n))),coldNums=new Set([...new Set([...setA,...setB])].filter(n=>!hotNums.has(n)));
 const top10=topNumbers(f100,10),seen10=new Set(recent.flatMap(d=>d.numbers));
 const overdue=new Set(top10.filter(n=>!seen10.has(n)));
 const pairCounts=new Map();for(const d of tail(hist,100))for(let i=0;i<6;i++)for(let j=i+1;j<6;j++){
   const k=`${d.numbers[i]}-${d.numbers[j]}`;pairCounts.set(k,(pairCounts.get(k)||0)+1);
 }
 const topPairs=new Set([...pairCounts.entries()].sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0])).slice(0,12).map(x=>x[0]));
 return {hist,prev,prev2,top10,core8:coreNumbers(hist),f100,f26,near:neighborsFrom(prev),hotNums,coldNums,overdue,topPairs};
}
function scoreCombo(c,ctx,w=state.weights,prefs={}) {
 const carry=intersection(c,ctx.prev).length;
 const lastDigits=new Set(ctx.prev.map(n=>n%10));
 const endPrev=c.some(n=>lastDigits.has(n%10));
 const endPairs=sameEndPairCount(c),total=sum(c),odd=c.filter(n=>n%2).length,gaps=nearGapCount(c),high=c.filter(n=>n>=41).length,hot=intersection(c,ctx.top10).length;
 const rates={
   carry:carry<=1?1:0,
   lastEnd:endPrev?1:0,
   endPairs:endPairs===1?1:endPairs===2?.6:endPairs===0?.4:0,
   sum:total>=140&&total<=159?1:total>=120&&total<=139?10/12:(total>=100&&total<=119)||(total>=160&&total<=180)?.5:0,
   odd:odd===3?1:odd===4?10/12:odd===2?8/12:0,
   gaps:gaps===3?1:gaps===2?.8:gaps===1?.6:0,
   high:high===0?1:high===1?.75:high===2?3/8:0,
   hot:hot===1?1:hot===2?.75:hot===3?.5:hot===0?.25:0
 };
 const max=Object.keys(defaults).reduce((a,k)=>a+(state.patterns[k]?(w[k]||0):0),0);const pts=Object.keys(defaults).reduce((a,k)=>a+(state.patterns[k]?(w[k]||0)*(rates[k]||0):0),0);
 const adjacent=c.filter(n=>ctx.near.has(n)).length;
 const mid=c.filter(n=>ctx.f26[n]>=3&&ctx.f26[n]<=4).length;
 const runs=consecutiveCount(c);
 const prev2=intersection(c,ctx.prev2).length;
 const coreHits=intersection(c,ctx.core8||[]).length;
 const corePref=prefs.coreMode==='1-2'?(coreHits>=1&&coreHits<=2?2.5:-2):prefs.coreMode==='2-3'?(coreHits>=2&&coreHits<=3?2.5:-2):0;
 const ac=acValue(c),primes=new Set([2,3,5,7,11,13,17,19,23,29,31,37,41,43]),primeCount=c.filter(n=>primes.has(n)).length;
 const colorCounts=[0,0,0,0,0];for(const n of c)colorCounts[n<=10?0:n<=20?1:n<=30?2:n<=40?3:4]++;
 const overdueCount=c.filter(n=>ctx.overdue.has(n)).length,hotCount=c.filter(n=>ctx.hotNums.has(n)).length,coldCount=c.filter(n=>ctx.coldNums.has(n)).length;
 let paired=0;for(let i=0;i<6;i++)for(let j=i+1;j<6;j++)if(ctx.topPairs.has(`${c[i]}-${c[j]}`))paired++;
 const bonus=(prefs.preferPrevious?(carry<=1?1.6:-2.5):0)
   +(prefs.preferNeighbors?(adjacent===1||adjacent===2?2:-1.4):0)
   +(prefs.preferNoRuns?(runs===0?2:runs===1?0:-3):0)
   +(prefs.preferMid?(mid>=1&&mid<=3?1.5:-.7):0)
   +(prefs.preferPrev2?(prev2<=2?1.4:-1.5):0)
   +(prefs.preferAc?(ac>=7&&ac<=10?1.6:-1.2):0)
   +(prefs.preferPrime?(primeCount>=1&&primeCount<=3?1.2:-1.0):0)
   +(prefs.preferColor?(Math.max(...colorCounts)<=3?1.2:-2):0)
   +(prefs.preferOverdue&&ctx.overdue.size?(overdueCount>=1&&overdueCount<=2?1.4:-.6):0)
   +(prefs.preferPairs&&ctx.topPairs.size?(paired>=1?1.5:-.6):0)
   +(prefs.preferHotCold?(hotCount>=1&&coldCount>=1?1.3:-.5):0)
   +corePref;
 return {pts,max,percent:max?Math.round(pts/max*100):0,rank:(max?pts/max*100:0)+bonus,details:{carry,endPairs,total,odd,gaps,high,hot,adjacent,mid,runs,prev2,coreHits,ac,primeCount,overdueCount,hotCount,coldCount,paired},rates};
}
function rngSample(rng=Math.random,weightedFreq=null){
 let available=Array.from({length:45},(_,i)=>i+1),res=[];
 for(let k=0;k<6;k++){
  let idx=0;
  if(weightedFreq){let ws=available.map(n=>Math.max(.15,1+((weightedFreq[n]||0)-weightedFreq.__expected)*.06));let z=sum(ws),r=rng()*z;while(idx<ws.length-1&&(r-=ws[idx])>=0)idx++;}
  else idx=Math.floor(rng()*available.length);
  res.push(available[idx]);available.splice(idx,1);
 }
 return res.sort((a,b)=>a-b);
}
function pickDiverse(scored,quantity,limit){
 const chosen=[],used=Array(46).fill(0),rejected=new Set();let usedLimit=limit;
 for(let allowance=limit;allowance<=5&&chosen.length<quantity;allowance++){
  for(let i=chosen.length;i<quantity;i++){
   let best=null,bestObjective=-Infinity,bestIndex=-1;
   for(let j=0;j<scored.length;j++){
    const obj=scored[j];if(rejected.has(obj.key))continue;
    if(chosen.some(p=>intersection(obj.nums,p.nums).length>allowance))continue;
    const repeats=obj.nums.reduce((a,n)=>a+used[n],0);
    const priority=obj.rating.rank-.6*repeats;
    if(priority>bestObjective){best=obj;bestObjective=priority;bestIndex=j;}
   }
   if(!best)break;
   chosen.push(best);rejected.add(best.key);for(const n of best.nums)used[n]++;usedLimit=Math.max(usedLimit,allowance);
  }
 }
 return {chosen,usedLimit};
}
function generateCandidatePool({count,ctx,mode='uniform',rng=Math.random,prefs={}}){
 const seen=new Set(),pool=[];
 let frequencies=null;
 if(mode==='weighted'){
   const f=ctx.f100;const h=ctx.hist.length?Math.min(100,ctx.hist.length):1;
   frequencies=[...f];frequencies.__expected=h*6/45;
 }
 const maxAttempts=count*3;
 for(let tries=0;pool.length<count&&tries<maxAttempts;tries++){
  const c=rngSample(rng,frequencies),key=c.join('-');if(seen.has(key))continue;seen.add(key);
  pool.push({nums:c,key,rating:scoreCombo(c,ctx,state.weights,prefs)});
 }
 if(prefs.coreMode && prefs.coreMode!=='off'){
  const [lo,hi]=prefs.coreMode==='2-3'?[2,3]:[1,2];
  const matching=pool.filter(x=>x.rating.details.coreHits>=lo&&x.rating.details.coreHits<=hi);
  if(matching.length>=20) {pool.length=0;pool.push(...matching);}
 }
 pool.sort((a,b)=>b.rating.rank-a.rating.rank || a.key.localeCompare(b.key));
 return pool;
}
function resultRowHtml(pick,index,{rankMode=true,savedMode=false,draw=null}={}){
 const c=pick.nums,sc=pick.rating;
 let right='';
 if(savedMode){
  const validDraw=draw?.no===pick.targetRound?draw:null;
  const r=validDraw?gradeTicket(c,validDraw):{grade:0,matches:[]};
  right=`<span class="pill">${!validDraw?'다른 회차':r.grade?`${r.grade}등`:`${r.matches.length}개 일치`}</span><button class="saved-delete" data-delete="${pick.id}" type="button" aria-label="번호 삭제">삭제</button>`;
 }else right=`<span class="score-badge">${sc?sc.percent:'–'}점</span><button class="small-button" data-save-pick="${index}" type="button">저장</button>`;
 const info=savedMode?`대상 ${pick.targetRound}회 · ${draw?.no===pick.targetRound?`${gradeTicket(c,draw).matches.length}개 일치 · ${gradeTicket(c,draw).bonus?'보너스 포함':'보너스 제외'}`:pick.targetRound>latest().no?'미추첨':'위에서 대상 회차 선택'}`:`합계 ${sum(c)} · 홀짝 ${c.filter(n=>n%2).length}:${c.filter(n=>n%2===0).length} · 끝수쌍 ${sameEndPairCount(c)} · 연속 ${consecutiveCount(c)}`;
 return `<div class="lotto-row ${!savedMode&&state.selectedGenerated.has(index)?'is-selected':''}">${!savedMode?`<input class="pick-check" type="checkbox" data-select-pick="${index}" aria-label="${index+1}번 조합 선택" ${state.selectedGenerated.has(index)?'checked':''}>`:''}<div class="rankno">${String(index+1).padStart(2,'0')}</div><div class="row-stack"><div class="balls">${ballsHtml(c,'small')}</div><div class="row-line"><span class="row-small">${info}</span><div class="row-side">${right}</div></div></div></div>`;
}
function toast(msg){const t=$('toast');t.textContent=msg;t.classList.add('visible');clearTimeout(toast.t);toast.t=setTimeout(()=>t.classList.remove('visible'),2900);}
function copyText(txt){if(navigator.clipboard?.writeText){navigator.clipboard.writeText(txt).then(()=>toast('클립보드에 복사했어요')).catch(()=>legacyCopy(txt));}else legacyCopy(txt);}
function legacyCopy(txt){const textArea=document.createElement('textarea');textArea.value=txt;document.body.appendChild(textArea);textArea.select();try{document.execCommand('copy');toast('클립보드에 복사했어요');}catch(_){toast('복사 기능을 사용할 수 없습니다.');}textArea.remove();}
function downloadFile(name,content,type='text/csv;charset=utf-8'){if(window.LottoAndroid?.saveCsv){window.LottoAndroid.saveCsv(name,content);return;}const blob=new Blob(['\ufeff',content],{type});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1200);}
function renderHome(){const d=latest(),hist=state.rows,ctx=buildContext(hist),f=ctx.f26,leader=topNumbers(f,3),prev=hist.length>1?hist.at(-2):null;
 let same=prev?intersection(d.numbers,prev.numbers).length:0,odd=d.numbers.filter(n=>n%2).length;
 $('weekLastRound').textContent=`제${nf(d.no)}회 · ${d.date||'날짜 미확인'}`;
 $('homeResults').innerHTML=`<div class="week-draw-balls">${ballsHtml(d.numbers)}<span class="week-draw-plus" aria-label="보너스 번호">+</span>${ballsHtml([d.bonus])}</div><div class="week-draw-caption">왼쪽 6개는 1등 번호 · + 오른쪽은 보너스 번호</div>`;
 $('homeStats').innerHTML=`<div class="mini-cards"><div class="mini-card"><span>분석 가능한 회차</span><strong>${nf(hist.length)}<small> 회</small></strong></div><div class="mini-card"><span>최근 26회 1위</span><strong>${leader[0]}<small>번 / ${f[leader[0]]}회</small></strong></div><div class="mini-card"><span>다음 추첨 분석</span><strong>${nf(d.no+1)}<small> 회</small></strong></div></div>${hist[0].no>1?`<div class="note"><strong>초기 자료 ${hist.length}회</strong><p>현재 ${hist[0].no}회부터 기록이 있어요. 전체 누적 통계를 사용하려면 오른쪽 상단 ? → 전체 당첨번호 갱신을 눌러주세요.</p></div>`:''}`;
 $('weekNextRound').textContent=`제${nf(d.no+1)}회`;
 $('weekDataBadge').textContent=haveWholeHistory()?`1~${d.no}회 반영`:`현재 ${hist.length}회 보유`;
 $('weeklyCoreBubbles').innerHTML=ballsHtml(coreNumbers(hist),'small');
}
function renderStats(){const n=$('statsRange').value,source=tail(state.rows,n),f=countFrequency(source),max=Math.max(...f),r=source.length,sorted=topNumbers(f,45),top=sorted.slice(0,11),low=[...sorted].reverse().sort((a,b)=>f[a]-f[b]||a-b).slice(0,10);
 $('statsSourceBadge').textContent=`제${source[0]?.no||'?'}~${source.at(-1)?.no||'?'}회 · ${source.length}회 · 보너스 제외${!haveWholeHistory()?' · 전체 기록 미완료':''}`;
 $('statsRangeHint').textContent=`${source[0]?.no}~${source.at(-1)?.no}회 · ${r}회 · 보너스 번호 제외${n==='all'&&!haveWholeHistory()?' · 전체 누적 자료 미완료':''}`;
 $('statsSummary').innerHTML=`<div class="tally-grid"><div class="tally"><span>집계 회차</span><strong>${nf(r)}회</strong></div><div class="tally"><span>번호당 기대 평균</span><strong>${(r*6/45).toFixed(2)}회</strong></div><div class="tally"><span>가장 많이 나온 번호</span><strong>${top[0]}번</strong><small>${f[top[0]]}회 출현</small></div><div class="tally"><span>가장 적게 나온 번호</span><strong>${low[0]}번</strong><small>${f[low[0]]}회 출현</small></div></div>`;
 $('freqChart').innerHTML=`<div class="freq-label">출현 횟수 상위 11개 · ${n==='all'&&!haveWholeHistory()?'현재 보유 데이터':'선택한 기간'}</div><div class="bubble-list" style="margin-bottom:18px">${top.map(n=>`<span class="bubble">${n}번 · ${f[n]}회</span>`).join('')}</div><div class="freq-grid">${Array.from({length:45},(_,i)=>i+1).map(n=>`<div class="freq-chip ${f[n]>=r*6/45*1.35?'hot':f[n]<r*6/45*.6?'cold':''}"><span class="ball tiny ${ballClass(n)}">${n}</span><small>${f[n]}회</small><div class="mini-bar"><span style="width:${max?f[n]/max*100:0}%"></span></div></div>`).join('')}</div>`;
 const counts={odd:Array(7).fill(0),pairs:[0,0,0,0],runs:[0,0,0]};let identicalColor=0,acRange=0,nearGaps=0;const pairCount=new Map();
 for(const d of source){let odd=d.numbers.filter(x=>x%2).length;counts.odd[odd]++;let p=sameEndPairCount(d.numbers);counts.pairs[Math.min(p,3)]++;counts.runs[Math.min(consecutiveCount(d.numbers),2)]++;let colors=[0,0,0,0,0];for(let x of d.numbers)colors[x<=10?0:x<=20?1:x<=30?2:x<=40?3:4]++;if(Math.max(...colors)>=4)identicalColor++;if(acValue(d.numbers)>=7&&acValue(d.numbers)<=10)acRange++;if(nearGapCount(d.numbers)>=1&&nearGapCount(d.numbers)<=3)nearGaps++;for(let i=0;i<6;i++)for(let j=i+1;j<6;j++){const key=`${d.numbers[i]}-${d.numbers[j]}`;pairCount.set(key,(pairCount.get(key)||0)+1);}}
 $('patternSummary').innerHTML=`<div class="panel"><div class="triplet"><div class="triplet-item"><span>홀짝 3:3</span><b>${counts.odd[3]}회</b></div><div class="triplet-item"><span>같은 끝수 1쌍</span><b>${counts.pairs[1]}회</b></div><div class="triplet-item"><span>연속번호 없는 회차</span><b>${counts.runs[0]}회</b></div><div class="triplet-item"><span>동일 색 4개 이상</span><b>${identicalColor}회</b></div><div class="triplet-item"><span>AC값 7~10</span><b>${acRange}회</b></div><div class="triplet-item"><span>간격 1~3 · 1~3곳</span><b>${nearGaps}회</b></div></div><p class="field-help">각 회차에 나타난 구조의 빈도입니다. 다음 회차 예측확률과는 다릅니다.</p><h3>자주 함께 나온 번호 쌍</h3><div class="bubble-list">${Array.from(pairCount.entries()).sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0])).slice(0,8).map(([key,c])=>`<span class="bubble">${key.replace('-', ' · ')} / ${c}회</span>`).join('')}</div></div>`;
 const a=state.rows.slice(-5),b=state.rows.slice(-10,-5),A=new Set(a.flatMap(d=>d.numbers)),B=new Set(b.flatMap(d=>d.numbers));
 const hot=[],cold=[],first=[];for(let n=1;n<=45;n++)(A.has(n)&&B.has(n)?hot:!A.has(n)&&!B.has(n)?first:cold).push(n);
 const group=(name,description,arr)=>`<div class="hot-group"><strong>${name} <span class="tag">${arr.length}개</span></strong><small>${description}</small><div class="bubble-list">${arr.length?arr.map(n=>`<span class="bubble">${n}</span>`).join(''):'없음'}</div></div>`;
 $('hotCold').innerHTML=group('핫수','최근 1~5회와 6~10회 양쪽 구간에 등장',hot)+group('첫수','최근 10회 두 구간 모두 미출현',first)+group('콜드수','최근 10회 중 한 구간에서만 등장',cold);
}

// v1.5: conditional, empirical pattern rates (not prediction); exact combinatorial baselines.
function choose(n,k){if(k<0||k>n)return 0;if(k===0||k===n)return 1;k=Math.min(k,n-k);let result=1;for(let i=1;i<=k;i++)result=result*(n-k+i)/i;return Math.round(result);}
const LOTTO_SPACE=choose(45,6);
function hyperProb(m,low,high){let ways=0;for(let k=low;k<=high;k++)ways+=choose(m,k)*choose(45-m,6-k);return ways/LOTTO_SPACE;}
function theoreticalSameEndPairOne(){
 const groups=Array(10).fill(0);for(let n=1;n<=45;n++)groups[n%10]++;
 let ways=0;for(let i=0;i<10;i++){
  let distinct4=0;
  for(let a=0;a<10;a++)for(let b=a+1;b<10;b++)for(let c=b+1;c<10;c++)for(let d=c+1;d<10;d++)if([a,b,c,d].every(z=>z!==i))distinct4+=groups[a]*groups[b]*groups[c]*groups[d];
  ways+=choose(groups[i],2)*distinct4;
 }
 return ways/LOTTO_SPACE;
}
function theoreticalColor4Plus(){return [10,10,10,10,5].reduce((acc,m)=>acc+hyperProb(m,4,6),0);}
function theoreticalSumBand(low,high){const dp=Array.from({length:7},()=>Array(276).fill(0));dp[0][0]=1;
 for(let n=1;n<=45;n++)for(let k=6;k>=1;k--)for(let t=275;t>=n;t--)dp[k][t]+=dp[k-1][t-n];
 return dp[6].slice(low,high+1).reduce((a,b)=>a+b,0)/LOTTO_SPACE;
}
const baseTheoretical={carry01:hyperProb(6,0,1),carry1:hyperProb(6,1,1),odd24:hyperProb(23,2,4),odd33:hyperProb(23,3,3),sameEnd1:theoreticalSameEndPairOne(),runs01:1-hyperConsecutiveAtLeast2(),sumBand:theoreticalSumBand(120,180),color4:theoreticalColor4Plus(),high01:hyperProb(5,0,1)};
function hyperConsecutiveAtLeast2(){
 // Count all sets with zero or exactly one adjacent pair. 6 isolated integers in [1,45]: C(40,6).
 // Exactly one adjacent pair and no other adjacency: 5 runs (lengths 2,1,1,1,1) in 45 places:
 // choose the position of length-2 run (5) * choose(40,5) arrangements with 5 runs and 4 required gaps.
 const noRuns=choose(40,6),oneRun=5*choose(40,5);
 return 1-(noRuns+oneRun)/LOTTO_SPACE;
}
function currentDigitPool(draw){const digits=new Set(draw.numbers.map(n=>n%10));const s=new Set();for(let n=1;n<=45;n++)if(digits.has(n%10))s.add(n);return s;}
function colorIndex(n){return n<=10?0:n<=20?1:n<=30?2:n<=40?3:4;}
function previousFocus(draw){const a=[0,0,0,0,0];for(const n of draw.numbers)a[colorIndex(n)]++;const max=Math.max(...a);return max>=4?{idx:a.indexOf(max),count:max}:null;}
function percent(p){return (p*100).toFixed(1)+'%';}
function probSampleEvents(rows,range){
 const selected=tail(rows,range),indexed=new Map(rows.map(d=>[d.no,d]));
 const pairs=[];for(const target of selected){const prev=indexed.get(target.no-1);if(prev)pairs.push({prev,target});}
 return {selected,pairs,missing:selected.length-pairs.length};
}
function transitionSpecs(){return [
  {id:'carry01',name:'전주 번호 0~1개 이월',desc:'바로 전 회차의 당첨번호가 다음 회차에 0개 또는 1개 재등장',ok:(prev,d)=>intersection(prev.numbers,d.numbers).length<=1,theory:()=>baseTheoretical.carry01},
  {id:'carry1',name:'전주 번호 정확히 1개 이월',desc:'전주 당첨번호 6개 중 정확히 1개가 다음 회차에도 나옴',ok:(prev,d)=>intersection(prev.numbers,d.numbers).length===1,theory:()=>baseTheoretical.carry1},
  {id:'neighbor12',name:'전주 ±1~2 번호 1~2개',desc:'전주 번호 자체를 제외한 ±1 또는 ±2 후보에서 1~2개 출현',ok:(prev,d)=>d.numbers.filter(n=>neighborsFrom(prev.numbers).has(n)).length>=1&&d.numbers.filter(n=>neighborsFrom(prev.numbers).has(n)).length<=2,theory:(prev)=>hyperProb(neighborsFrom(prev.numbers).size,1,2)},
  {id:'endsRepeat',name:'전주와 동일 끝수 재등장',desc:'전주 당첨번호 중 적어도 하나와 일의 자리가 같은 번호가 출현',ok:(prev,d)=>d.numbers.some(n=>currentDigitPool(prev).has(n)),theory:(prev)=>1-hyperProb(currentDigitPool(prev).size,0,0)},
  {id:'bonus',name:'전주 보너스 번호 재등장',desc:'전주 보너스 번호가 다음 회차의 기본 당첨번호에 포함',ok:(prev,d)=>d.numbers.includes(prev.bonus),theory:()=>6/45}
 ];}
function structureSpecs(){return [
  {id:'endOne',name:'동일 끝수 정확히 1쌍',desc:'6개 번호에서 끝수가 같은 번호 쌍이 정확히 하나',ok:(_,d)=>sameEndPairCount(d.numbers)===1,theory:()=>baseTheoretical.sameEnd1},
  {id:'odd24',name:'홀수 2~4개',desc:'홀수 개수가 2개, 3개 또는 4개',ok:(_,d)=>{const k=d.numbers.filter(n=>n%2).length;return k>=2&&k<=4;},theory:()=>baseTheoretical.odd24},
  {id:'odd33',name:'홀짝 비율 3:3',desc:'홀수 3개와 짝수 3개',ok:(_,d)=>d.numbers.filter(n=>n%2).length===3,theory:()=>baseTheoretical.odd33},
  {id:'run01',name:'연속번호 0~1쌍',desc:'정렬한 번호에서 차이 1인 인접쌍이 0개 또는 1개',ok:(_,d)=>consecutiveCount(d.numbers)<=1,theory:()=>baseTheoretical.runs01},
  {id:'sumBand',name:'번호 합계 120~180',desc:'기본 당첨번호 6개를 더한 합계가 120~180',ok:(_,d)=>{const s=sum(d.numbers);return s>=120&&s<=180;},theory:()=>baseTheoretical.sumBand},
  {id:'high01',name:'41~45번 0~1개',desc:'41~45번에 속한 숫자가 0개 또는 1개',ok:(_,d)=>d.numbers.filter(n=>n>=41).length<=1,theory:()=>baseTheoretical.high01},
  {id:'color4',name:'같은 색 번호 4개 이상',desc:'1~10 / 11~20 / 21~30 / 31~40 / 41~45 중 한 구간에 4개 이상',ok:(_,d)=>{const cc=[0,0,0,0,0];for(const n of d.numbers)cc[colorIndex(n)]++;return Math.max(...cc)>=4;},theory:()=>baseTheoretical.color4}
 ];}
function probabilityRow(spec,pairs){
 const count=pairs.filter(({prev,target})=>spec.ok(prev,target)).length,n=pairs.length;
 const observed=n?count/n:null;
 const expect=n?pairs.reduce((a,{prev})=>a+spec.theory(prev),0)/n:null;
 const color=observed!==null&&expect!==null&&Math.abs(observed-expect)>0.18?' high-delta':'';
 return `<article class="prob-row${color}"><div class="prob-row-top"><strong>${spec.name}</strong><span class="prob-count">${count}/${n}회</span></div><div class="prob-row-values"><span><b>${observed===null?'—':percent(observed)}</b><small>과거 관측</small></span><span><b>${expect===null?'—':percent(expect)}</b><small>기간 평균 이론</small></span></div><div class="prob-tracks"><div class="prob-track"><span class="observed" style="width:${observed===null?0:observed*100}%"></span></div><div class="prob-track"><span class="expected" style="width:${expect===null?0:expect*100}%"></span></div></div><p class="prob-description">${spec.desc}</p></article>`;
}
function renderProbability(){
 const range=$('probRange').value;
 const {selected,pairs,missing}=probSampleEvents(state.rows,range);
 const recordLimited=range==='all'&&!haveWholeHistory();
 const requested=range==='all'?null:Number(range);
 const selectedInfo=`제${selected[0]?.no||'?'}~${selected.at(-1)?.no||'?'}회 · 비교 가능 ${pairs.length}회 / 선택 ${selected.length}회`;
 const caution=recordLimited?'전체 기록을 아직 모두 불러오지 않았어요. 현재 보유한 자료만 계산한 값입니다.':(requested&&selected.length<requested?`최근 ${requested}회 중 확보한 기록은 ${selected.length}회뿐이에요. 전체 데이터를 갱신하면 더 정확한 기간을 볼 수 있어요.`:'');
 $('probRangeInfo').textContent=selectedInfo+(missing?` · 앞 회차 자료 없음 ${missing}건`:'')+(caution?' · '+caution:'');
 const last=latest(),prev=state.rows.find(d=>d.no===last.no-1);
 const lastNear=neighborsFrom(last.numbers),lastDigits=currentDigitPool(last);
 const digitLabels=[...new Set(last.numbers.map(n=>n%10))].sort((a,b)=>a-b).join(' · ');
 const colors=[0,0,0,0,0];for(const x of last.numbers)colors[colorIndex(x)]++;
 const lastColor=previousFocus(last),colorNames=['1~10','11~20','21~30','31~40','41~45'];
 $('probPrevious').innerHTML=`<div class="prob-latest panel"><div class="prob-overline"><strong>다음 제${last.no+1}회 분석 기준</strong><small>전주 제${last.no}회 · ${last.date||'날짜 미확인'}</small></div><div class="balls">${ballsHtml(last.numbers,'small')}</div><div class="prob-mini-metrics"><div><small>전주 ±1~2 후보</small><b>${lastNear.size}개</b></div><div><small>지난주 끝수 종류</small><b>${new Set(last.numbers.map(n=>n%10)).size}개</b></div><div><small>전주 색상 집중</small><b>${lastColor?colorNames[lastColor.idx]+' · '+lastColor.count+'개':'4개 이상 없음'}</b></div></div><div class="prob-latest-theory"><strong>다음 제${last.no+1}회 무작위 추첨의 이론적 발생률</strong><div><span>전주 번호 0~1개 재등장 <b>${percent(baseTheoretical.carry01)}</b></span><span>전주 ±1~2에서 1~2개 <b>${percent(hyperProb(lastNear.size,1,2))}</b></span><span>전주와 같은 끝수 ≥1개 <b>${percent(1-hyperProb(lastDigits.size,0,0))}</b></span></div><small>실제 당첨 예측이 아닌, 전주 번호로 후보군을 정의했을 때의 조합론 확률이에요.</small></div></div><details class="prob-more"><summary>전주 기준 인접수·끝수 후보 보기</summary><div><strong>±1~2 후보 · ${lastNear.size}개</strong><p>${[...lastNear].sort((a,b)=>a-b).join(', ')||'없음'}</p><strong>기존 끝수</strong><p>${digitLabels} (${lastDigits.size}개 번호가 이 끝수에 해당)</p></div></details></div>`;
 if(!pairs.length){$('probTransition').innerHTML='<div class="empty-state"><strong>비교 가능한 두 회차가 없어요</strong><p>데이터를 갱신하거나 JSON 파일을 가져오세요.</p></div>';$('probStructure').innerHTML='';$('probColorFocus').innerHTML='';return;}
 $('probTransition').innerHTML=transitionSpecs().map(s=>probabilityRow(s,pairs)).join('');
 $('probStructure').innerHTML=structureSpecs().map(s=>probabilityRow(s,pairs)).join('');
 // Conditional historical transitions after a concentrated color; avoid percentage with tiny samples.
 const concentrated=pairs.filter(({prev})=>previousFocus(prev));
 if(concentrated.length){const favorable=concentrated.filter(({prev,target})=>{
   const idx=previousFocus(prev).idx;return target.numbers.filter(n=>colorIndex(n)===idx).length<=2;
 }).length;
 $('probColorFocus').innerHTML=`<div class="prob-color-focus"><strong>참고 · 색상 집중 이후의 다음 회차</strong><p>이전 회차에 같은 색 번호가 4개 이상 몰린 경우만 따로 보면, 다음 회차에 그 색이 0~2개 등장한 사례는 <b>${favorable}/${concentrated.length}회</b>야. ${concentrated.length<20?'표본이 적어서 예측 자료로 사용하기 어려워요.':'관측 비율만으로 다음 추첨의 확률을 단정할 수 없어요.'}</p></div>`;
 }else $('probColorFocus').innerHTML=`<div class="prob-color-focus"><strong>참고 · 색상 집중 이후의 다음 회차</strong><p>이 기간에는 전주에 같은 색 번호가 4개 이상 나온 사례가 없어 조건부 발생률을 표시하지 않았어요.</p></div>`;
}

function renderWeights(){const enabledTotal=Object.keys(defaults).reduce((v,k)=>v+(state.patterns[k]?state.weights[k]:0),0);
 $('weightInputs').innerHTML=`<div class="weight-grid">${Object.keys(defaults).map(k=>`<div class="weight-item ${state.patterns[k]?'':'pattern-weight-off'}"><label for="weight-${k}">${weightLabels[k]} ${state.patterns[k]?'':'· OFF'}</label><input type="number" min="0" max="30" step="1" id="weight-${k}" data-weight="${k}" value="${state.weights[k]}" ${state.patterns[k]?'':'disabled'}></div>`).join('')}</div><p class="subnote">현재 활성화된 점수 최고점: ${enabledTotal}점 · 0점 항목은 추천 순위에 적용되지 않아요.</p>`;
}
function renderPatternToggles(){
 const item=spec=>`<label class="pattern-switch-row ${state.patterns[spec.id]?'is-on':'is-off'}"><span class="pattern-switch-copy"><strong>${spec.name}</strong><small>${spec.description}</small></span><span class="pattern-switch"><input type="checkbox" data-pattern="${spec.id}" ${state.patterns[spec.id]?'checked':''} aria-label="${spec.name} 활성화"><span class="pattern-switch-track"></span></span></label>`;
 $('scorePatternToggles').innerHTML=scorePatternSpecs.map(item).join('');
 $('extraPatternToggles').innerHTML=extraPatternSpecs.map(item).join('');
 const enabled=Object.values(state.patterns).filter(Boolean).length;
 $('patternEnabledCount').textContent=`${enabled}/${Object.keys(defaultPatternToggles).length}개 사용 중`;
 $('coreMode').disabled=!state.patterns.coreLimit;
 renderWeights();
}
function markGenerationDirty(){state.settingsDirty=true;$('settingNotice').hidden=false;}
function persistPatterns(){writeStore(keys.patterns,state.patterns);renderPatternToggles();markGenerationDirty();}


function activePatternOptions(){
 const prefs={...Object.fromEntries(extraPatternSpecs.map(p=>[p.id,!!state.patterns[p.id]])),coreMode:state.patterns.coreLimit?$('coreMode').value:'off'};
 return {candidate:Number($('candidateCount').value),quantity:Number($('pickCount').value),mode:$('genMode').value,limit:Number($('maxOverlap').value),prefs};
}
function matchGeneratedSets(a,b){
 const overlap=[];for(const x of a){let best=0;for(const y of b)best=Math.max(best,intersection(x,y).length);overlap.push(best);}return overlap;
}
function renderGenerator(){
 $('generatorRound').textContent=`제${latest().no+1}회 · 직전 ${latest().no}회까지 분석`;
 if(!state.generated.length)return;
 const chosen=state.generated,points=chosen.map(p=>p.rating.percent),usedLimit=state.genMeta?.usedLimit||2;
 const previous=Array.isArray(state.previousGenerated)?state.previousGenerated.filter(x=>Array.isArray(x)&&x.length===6):[];
 const previousMatches=previous.length?matchGeneratedSets(chosen.map(x=>x.nums),previous):[];
 const shared=previousMatches.filter(x=>x>=3).length;
 $('selectionNotice').textContent=`${state.selectedGenerated.size}개 선택 · 체크한 번호만 보관함에 저장할 수 있어요.`;
 $('generatedResults').innerHTML=`<div class="result-heading"><strong>추천 ${chosen.length}조합</strong><small>점수 ${Math.min(...points)}~${Math.max(...points)}점</small></div>
 <div class="select-all-bar"><label><input type="checkbox" id="selectAllGenerated" ${state.selectedGenerated.size===chosen.length?'checked':''}> 전체 선택</label><small>선택 ${state.selectedGenerated.size}/${chosen.length}조합</small></div>
 <div class="pick-list">${chosen.map((p,i)=>resultRowHtml(p,i)).join('')}</div>
 <div class="action-bar"><button class="small-primary" id="saveSelected" type="button">선택한 번호 저장 (${state.selectedGenerated.size})</button><button class="small-button" id="copyGenerated" type="button">전체 복사</button><button class="small-button" id="saveGenerated" type="button">전체 저장</button><button class="small-button" id="exportGenerated" type="button">CSV</button></div>
 <details class="compare-generated"><summary>이전 추천과 비교 ${previous.length?'· '+previous.length+'조합':'· 기록 없음'}</summary>${previous.length?`<p>현재 조합 중 이전 추천과 <b>3개 이상 겹치는 조합 ${shared}개</b> · 정확히 같은 6개 번호 조합 <b>${previousMatches.filter(x=>x===6).length}개</b></p><p class="field-help">서로 다른 조합끼리 가장 많이 겹친 번호 수를 비교한 값이야. 적중률이나 당첨 확률은 아니야.</p>`:'<p>조합을 한 번 더 생성하면 이전 생성 결과와 비교할 수 있어요.</p>'}</details>
 <details class="generator-result-details"><summary>생성 결과 상세 보기</summary><div class="tally-grid"><div class="tally"><span>무작위 후보</span><strong>${nf(state.genMeta?.candidate||0)}개</strong></div><div class="tally"><span>조합 간 최대 공통번호</span><strong>${usedLimit}개 이하</strong><small>${usedLimit>Number($('maxOverlap').value)?'조건 완화하여 선정':'선택한 조건으로 선정'}</small></div></div><p class="field-help">핵심번호 조건: ${state.genMeta?.coreMode==='off'?'강제하지 않음':state.genMeta?.coreMode||'강제하지 않음'}</p></details><p class="field-help">패턴 점수는 조건 적합도이며, 1등 당첨 확률은 어떤 6개 조합이나 1/8,145,060으로 같습니다.</p>`;
}

function persistSaved(){writeStore(keys.saved,state.saved);renderSaved();}
function saveTicket(nums){const c=nums.slice().sort((a,b)=>a-b),target=latest().no+1,key=`${target}-${c.join('-')}`;
 if(state.saved.some(x=>x.key===key)){return false;}
 state.saved.push({id:Date.now().toString(36)+Math.random().toString(36).slice(2,7),key,nums:c,targetRound:target});return true;
}
function renderSaved(){
 const sel=$('checkRound'),selected=Number(sel.value)||latest().no;
 const available=state.rows.slice(-120).reverse();
 sel.innerHTML=available.map(d=>`<option value="${d.no}" ${d.no===selected?'selected':''}>${d.no}회 · ${d.date}</option>`).join('');
 const draw=state.rows.find(d=>d.no===Number(sel.value))||latest();
 const saved=state.saved.filter(p=>Array.isArray(p.nums)&&p.nums.length===6&&Number.isInteger(Number(p.targetRound)));
 const groups=new Map();for(const p of saved){const key=Number(p.targetRound);if(!groups.has(key))groups.set(key,[]);groups.get(key).push(p);}
 const sorted=Array.from(groups.entries()).sort((a,b)=>b[0]-a[0]);
 const wins=saved.filter(p=>p.targetRound===draw.no&&gradeTicket(p.nums,draw).grade>0).length;
 const html=sorted.map(([round,items])=>{const result=state.rows.find(d=>d.no===round);let winCount=0;if(result)winCount=items.filter(p=>gradeTicket(p.nums,result).grade>0).length;
 const label=result?`추첨 완료 · 당첨 ${winCount}조합`:round>latest().no?'추첨 전 · 당첨 확인 대기':'당첨번호 데이터 미보유';
 return `<details class="saved-round-group" ${round===latest().no+1?'open':''}><summary><span>제${round}회 <small>${items.length}조합</small></span><span class="saved-round-status">${label}</span></summary><div class="pick-list">${items.slice().reverse().map((p,i)=>resultRowHtml(p,i,{savedMode:true,draw:result||null})).join('')}</div></details>`;
 }).join('');
 $('savedResults').innerHTML=`<div class="tally-grid"><div class="tally"><span>저장한 조합</span><strong>${saved.length}개</strong></div><div class="tally"><span>선택 회차 당첨</span><strong>${wins}개</strong><small>선택된 회차 당첨번호와 비교</small></div></div>${saved.length?html:'<div class="empty-state"><span class="empty-icon">♡</span><strong>아직 저장한 번호가 없어요</strong><p>번호를 직접 입력하거나 추천번호에서 선택 저장하세요.</p></div>'}`;
}

function gradeTicket(c,d){const matches=intersection(c,d.numbers),bonus=c.includes(d.bonus);let grade=0;if(matches.length===6)grade=1;else if(matches.length===5&&bonus)grade=2;else if(matches.length===5)grade=3;else if(matches.length===4)grade=4;else if(matches.length===3)grade=5;return {grade,matches,bonus};}
const nextFrame=()=>new Promise(r=>setTimeout(r,0));
async function runGenerator(){if(state.busy)return;state.busy=true;const btn=$('generateBtn');btn.disabled=true;btn.textContent='조합 평가 중…';$('generateProgress').hidden=false;
 try {
  const {candidate,quantity,mode,limit,prefs}=activePatternOptions(),ctx=buildContext(state.rows);
  $('generateProgressBar').style.width='15%';$('generateProgressText').textContent=`${nf(candidate)}개 후보를 생성합니다…`;await nextFrame();
  const pool=generateCandidatePool({count:candidate,ctx,mode,prefs});$('generateProgressBar').style.width='72%';$('generateProgressText').textContent='패턴 적합도 평가 및 조합 분산…';await nextFrame();
  const selection=pickDiverse(pool,quantity,limit);
  if(state.generated.length){state.previousGenerated=state.generated.map(p=>p.nums.slice());writeStore(previousGenerationKey,state.previousGenerated);}
  state.selectedGenerated.clear();state.generated=selection.chosen;state.settingsDirty=false;$('settingNotice').hidden=true;state.genMeta={candidate:pool.length,usedLimit:selection.usedLimit,coreMode:prefs.coreMode};$('generateProgressBar').style.width='100%';renderGenerator();toast(`${selection.chosen.length}개 조합을 생성했어요`);
 }catch(e){toast('생성 중 오류: '+e.message);}finally{state.busy=false;btn.disabled=false;btn.textContent='✦ 이 조건으로 조합 생성';setTimeout(()=>$('generateProgress').hidden=true,500);}
}
function renderDataStatus(){$('dataStatus').innerHTML=`<strong>${state.dataMode}</strong><br>제${state.rows[0]?.no}회 ~ 제${latest()?.no}회 · ${nf(state.rows.length)}회 ${haveWholeHistory()?'· 전체 누적 사용 가능':'· 전체 누적 일부 제한'}`;}
async function refreshData(silent=false){
 if(state.syncing) return;
 state.syncing=true;state.syncError='';renderSyncStatus();const btn=$('refreshData');btn.disabled=true;btn.textContent='전체 기록을 불러오는 중…';
 try{
  let payload=null,error=null;
  for(const url of [dataURL,fallbackURL]){
   try{const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),15000);
    try{const res=await fetch(url+'?v='+Math.floor(Date.now()/3600000),{cache:'no-store',mode:'cors',signal:controller.signal});if(!res.ok)throw Error(`HTTP ${res.status}`);payload=await res.json();}finally{clearTimeout(timer);}
    break;
   }catch(e){error=e;}
  }
  if(!payload)throw(error||new Error('온라인 연결 실패'));
  const fresh=normalizeList(payload);
  if(fresh.length<state.rows.length/2)throw new Error('받아온 회차가 너무 적습니다');
  // Reject a payload that would replace current data with an older latest draw.
  if(fresh.at(-1).no<latest().no)throw new Error('온라인 자료가 현재 보유 기록보다 오래되었습니다');
  state.rows=mergeDraws(state.rows,fresh);state.dataMode='온라인 전체 기록';
  const cached=writeStore(keys.draws,state.rows);
  try{localStorage.setItem(keys.sync,String(Date.now()));}catch(_){}
  renderAll();if(!silent)toast(`제${latest().no}회까지 갱신 완료${cached?'':' · 캐시 저장 실패'}`);
 }catch(e){state.syncError=String(e?.message||e).slice(0,125);console.warn(e);if(!silent)toast(`갱신 실패: ${state.syncError}`);}
 finally{state.syncing=false;btn.disabled=false;btn.textContent='↻ 전체 당첨번호 갱신';renderSyncStatus();}
}
function refreshIfDue(){
 if(state.syncing||navigator.onLine===false)return;
 let last=0;try{last=Number(localStorage.getItem(keys.sync))||0;}catch(_){}
 if(Date.now()-last>AUTO_REFRESH_MS)refreshData(true);
}
async function importDataFile(file){if(!file)return;try{const payload=JSON.parse(await file.text());const fresh=normalizeList(payload);state.rows=mergeDraws(state.rows,fresh);state.dataMode='가져온 JSON 기록';writeStore(keys.draws,state.rows);renderAll();toast(`${nf(fresh.length)}회 자료를 가져왔어요`);}catch(e){toast('파일을 읽지 못했어요: '+e.message);}}
// Date-based cultural reflection. Calendar pillars are APPROXIMATE for v1.8:
// solar terms use typical local calendar days, without precise astronomical seconds;
// day pillar uses an independently checked 2026-11-04 壬午 anchor. No fortune claims.
const FATE_GAN='甲乙丙丁戊己庚辛壬癸'.split('');
const FATE_ZHI='子丑寅卯辰巳午未申酉戌亥'.split('');
const FATE_ANIMALS=['쥐','소','호랑이','토끼','용','뱀','말','양','원숭이','닭','개','돼지'];
const FATE_ELEMENTS=['목','목','화','화','토','토','금','금','수','수'];
const FATE_ELEMENT_ORDER=['목','화','토','금','수'];
const FATE_ANIMAL_RELATIONS={'0-1':'합','2-11':'합','3-10':'합','4-9':'합','5-8':'합','6-7':'합'};
const FATE_CLASHES=new Set(['0-6','1-7','2-8','3-9','4-10','5-11']);
const FATE_PROFILE_KEY='lotto-lab-fate-profile-optin-v18';
const mod=(x,n)=>((x%n)+n)%n;
function kstDateParts(){
 const ps=new Intl.DateTimeFormat('en-US',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date());
 const get=x=>Number(ps.find(p=>p.type===x)?.value);
 return {y:get('year'),m:get('month'),d:get('day')};
}
function fmtYmd(p){return [p.y,String(p.m).padStart(2,'0'),String(p.d).padStart(2,'0')].join('-');}
function validateIsoDate(value){
 if(!/^\d{4}-\d{2}-\d{2}$/.test(value||''))return null;
 const [y,m,d]=value.split('-').map(Number),check=new Date(Date.UTC(y,m-1,d));
 if(check.getUTCFullYear()!==y||check.getUTCMonth()!==m-1||check.getUTCDate()!==d||y<1901||y>2099)return null;
 return {y,m,d};
}
function fatePillar(gan,zhi){return {gan:FATE_GAN[gan],zhi:FATE_ZHI[zhi],ganIndex:gan,zhiIndex:zhi,element:FATE_ELEMENTS[gan]};}
function approximatePillars(date,time){
 const p=typeof date==='string'?validateIsoDate(date):date;
 if(!p)throw new Error('생년월일을 다시 확인해 주세요.');
 const q=p.m*100+p.d;
 const solYear=p.y-(q<204?1:0);
 const yg=mod(solYear-1984,10),yz=mod(solYear-1984,12);
 // 절기 근사(입춘2/4, 경칩3/6, 청명4/5, 입하5/6, 망종6/6 ...)
 const starts=[204,306,405,506,606,707,808,908,1008,1107,1207];
 let monthIndex=q<204?(q<106?10:11):0;
 if(q>=204){for(let i=0;i<starts.length;i++)if(q>=starts[i])monthIndex=i;}
 const mg=mod((yg%5)*2+2+monthIndex,10),mz=mod(2+monthIndex,12);
 const diff=Math.round((Date.UTC(p.y,p.m-1,p.d)-Date.UTC(2026,10,4))/86400000);
 const dg=mod(8+diff,10),dz=mod(6+diff,12);
 let hourPillar=null;
 if(typeof time==='string'&&/^\d\d:\d\d$/.test(time)){
  const [h,mi]=time.split(':').map(Number);
  if(h<0||h>23||mi<0||mi>59)throw new Error('출생 시각을 다시 확인해 주세요.');
  const hourIdx=Math.floor(mod(h+1,24)/2),hg=mod((dg%5)*2+hourIdx,10);
  hourPillar=fatePillar(hg,hourIdx);
 }
 return {year:fatePillar(yg,yz),month:fatePillar(mg,mz),day:fatePillar(dg,dz),hour:hourPillar};
}
function sajuElementLink(from,to){
 const a=FATE_ELEMENT_ORDER.indexOf(from),b=FATE_ELEMENT_ORDER.indexOf(to);
 if(a===b)return {name:'비슷한 기운',summary:'내 일간과 오늘 일간의 오행이 같아요. 익숙한 방식으로 차분하게 움직이되, 고집을 조금 내려놓는 연습이 어울려요.',verb:'내 페이스 조절'};
 if((a+1)%5===b)return {name:'내가 힘을 보태는 관계',summary:'내 일간이 오늘의 기운을 북돋는 배치예요. 누군가를 돕거나 쌓아 온 것을 정리하는 흐름으로 읽을 수 있어요.',verb:'작은 정리'};
 if((b+1)%5===a)return {name:'도움을 받는 관계',summary:'오늘의 기운이 내 일간을 도와주는 배치예요. 무리하기보다 주변의 도움과 작은 배움을 활용해 보세요.',verb:'배움과 회복'};
 if((a+2)%5===b)return {name:'내가 주도하는 관계',summary:'전통 오행 해석에서는 내 기운이 오늘의 기운을 다스리는 배치예요. 조급한 결론 대신 우선순위를 세우는 것이 좋아요.',verb:'우선순위'};
 return {name:'속도를 조절할 관계',summary:'전통 오행 해석에서는 오늘의 기운이 내 기운을 다스리는 배치예요. 무리한 약속이나 피로를 조금 줄여보세요.',verb:'차분한 판단'};
}
function branchLink(a,b){const k=[a,b].sort((x,y)=>x-y).join('-');return FATE_CLASHES.has(k)?'충(상반된 위치)':FATE_ANIMAL_RELATIONS[k]?'합(서로 잇는 위치)':'일반적인 관계';}
function sajuReading(){
 const dob=$('sajuBirthDate').value,day=$('sajuReadDate').value;
 const birthday=validateIsoDate(dob),today=validateIsoDate(day);
 if(!birthday||!today)throw new Error('생일과 조회 날짜를 올바르게 선택해 주세요.');
 const unknown=$('sajuTimeUnknown').checked,time=unknown?null:$('sajuBirthTime').value;
 const birth=approximatePillars(birthday,time),now=approximatePillars(today,null);
 const relationship=sajuElementLink(birth.day.element,now.day.element);
 const branch=branchLink(birth.day.zhiIndex,now.day.zhiIndex);
 return {birth,now,relationship,branch,date:day,birthDate:dob,time:unknown?'':time};
}
function pillarHtml(title,p){return `<div class="pillar-tile"><small>${title}</small>${p?`<strong>${p.gan}${p.zhi}</strong><span>${p.element} · ${FATE_ANIMALS[p.zhiIndex]}</span>`:'<strong>—</strong><span>시간 모름</span>'}</div>`;}
function renderSajuResults(){
 let x;try{x=sajuReading();}catch(err){$('sajuResult').innerHTML=`<div class="fate-error">${err.message}</div>`;return;}
 const t=x.relationship,ganName=FATE_ANIMALS[x.birth.year.zhiIndex]+'띠';
 $('sajuResult').innerHTML=`<div class="saju-reading-card">
   <div class="saju-reading-top"><div><span>나의 오늘 · ${x.date}</span><h2>${t.verb}에 집중해 보는 하루</h2><p>내 일간 <b>${x.birth.day.gan}(${x.birth.day.element})</b>과 오늘 일간 <b>${x.now.day.gan}(${x.now.day.element})</b>을 비교했어요.</p></div><span class="saju-main-glyph">${x.now.day.gan}${x.now.day.zhi}</span></div>
   <div class="saju-pillars-label">나의 사주 네 기둥 <small>간이 산출 · 양력 기준</small></div>
   <div class="saju-pillars">${pillarHtml('연주',x.birth.year)}${pillarHtml('월주',x.birth.month)}${pillarHtml('일주',x.birth.day)}${pillarHtml('시주',x.birth.hour)}</div>
   <div class="saju-today-label">오늘의 일진 <b>${x.now.day.gan}${x.now.day.zhi}</b> · 내 일지와의 관계 ${x.branch}</div>
   <div class="saju-relationship"><span>☯ ${t.name}</span><p>${t.summary}</p></div>
   <div class="saju-reading-list"><div><strong>🌿 오늘의 종합운</strong><p>${ganName}로 태어난 나의 기질을 참고하되, 현재 상황을 가장 먼저 살펴보세요. 작은 계획 하나를 마무리하는 데 의미를 두면 좋아요.</p></div>
   <div><strong>♡ 관계운</strong><p>${x.branch.startsWith('충')?'서로 다른 의견이 생기면 설명을 한 번 더 듣고 이야기해 보세요.':'내 생각을 적절히 표현하고 상대의 마음을 확인해 보는 시간이 좋아요.'}</p></div>
   <div><strong>✎ 일·생활운</strong><p>${t.verb}을 실천하기 좋은 날로 생각해 보세요. 해야 할 일을 한 가지만 골라도 성취감이 생길 수 있어요.</p></div>
   <div><strong>◇ 금전운</strong><p>충동적인 지출보다는 오늘 계획한 예산을 확인해 보세요. 실제 금전 판단은 운세가 아닌 수입·지출 정보에 따라 결정하는 게 좋아요.</p></div></div>
   <p class="saju-disclaimer">이 결과는 사주팔자의 전통적인 오행 관계를 일상 문장으로 풀이한 <b>참고용 해석</b>이야. 절기의 정확한 분·초 및 출생지 보정을 하지 않은 간이 만세력이며 미래를 예측하지 않아요. 특히 23시 전후와 절기 경계 출생은 정밀 만세력 결과와 다를 수 있어요.</p>
 </div>`;
 if($('sajuRemember').checked){try{localStorage.setItem(FATE_PROFILE_KEY,JSON.stringify({date:x.birthDate,time:x.time,unknown:$('sajuTimeUnknown').checked,accepted:true}));}catch(_){}}
 else{try{localStorage.removeItem(FATE_PROFILE_KEY);}catch(_){}}
}
function initSaju(){
 $('sajuReadDate').value=fmtYmd(kstDateParts());
 try{
  const saved=JSON.parse(localStorage.getItem(FATE_PROFILE_KEY)||'null');
  if(saved?.accepted&&validateIsoDate(saved.date)){
   $('sajuBirthDate').value=saved.date;$('sajuBirthTime').value=saved.time||'12:00';
   $('sajuTimeUnknown').checked=!!saved.unknown;$('sajuRemember').checked=true;
  }
 }catch(_){ }
 $('sajuBirthTime').disabled=$('sajuTimeUnknown').checked;
}
function gotoFateTab(tab){
 const isTarot=tab==='tarot';
 $('fateSaju').classList.toggle('hidden',isTarot);$('fateTarot').classList.toggle('hidden',!isTarot);
 document.querySelectorAll('[data-fate-tab]').forEach(b=>{const sel=b.dataset.fateTab===tab;b.classList.toggle('active',sel);b.setAttribute('aria-selected',String(sel));});
}
const MAJOR_ARCANA=[
 ['바보','✺','새로운 시작','완벽한 준비보다 가벼운 첫걸음이 중요한 때예요.','작게 한 가지를 시작해 보기'],
 ['마법사','✦','가능성과 실행','이미 가진 자원에서 오늘 필요한 힌트를 찾을 수 있어요.','가장 손쉬운 행동부터 정하기'],
 ['여사제','☾','직감과 관찰','지금은 서두르지 않고 조용히 관찰하는 힘이 필요해요.','내 감정을 메모하기'],
 ['여황제','❀','돌봄과 성장','작은 관심이 마음을 채우는 시간이 될 수 있어요.','나에게 다정한 행동 하나'],
 ['황제','♛','기준과 안정','중요한 일의 경계와 기준을 분명하게 세워보세요.','오늘의 원칙 한 가지 정하기'],
 ['교황','♜','배움과 연결','배울 마음을 열어두면 다른 관점이 보일 수 있어요.','경험 있는 이의 조언 듣기'],
 ['연인','♡','관계와 선택','마음이 향하는 것과 지키고 싶은 가치를 함께 보세요.','진심을 차분히 표현하기'],
 ['전차','➶','의지와 방향','하나의 목표에 집중하면 길이 조금 선명해질 거예요.','우선순위를 하나로 줄이기'],
 ['힘','♌','온화한 용기','부드러운 태도가 생각보다 큰 힘이 될 수 있어요.','감정을 다독이고 다시 시작하기'],
 ['은둔자','✧','휴식과 성찰','혼자 생각하는 시간에서 필요한 힌트가 보일 수 있어요.','조용한 시간 마련하기'],
 ['운명의 수레바퀴','◉','변화의 흐름','예상 밖의 변화에도 내가 고를 수 있는 행동이 있어요.','통제 가능한 것 적기'],
 ['정의','⚖','균형과 판단','사실과 감정을 구분해 바라보면 도움이 될 거예요.','한 번 더 확인하기'],
 ['매달린 사람','◇','새로운 시선','잠시 멈추면 전에는 보지 못한 점이 보여요.','다른 입장에서 생각하기'],
 ['죽음','❋','정리와 전환','익숙한 것을 정리할 때 새로운 공간이 생길 수 있어요.','미룬 일 하나 정리하기'],
 ['절제','⚗','조화와 페이스','극단을 피하고 나에게 맞는 리듬을 찾아보세요.','과한 일을 하나 덜어내기'],
 ['악마','⛓','습관과 선택','나를 붙잡는 익숙한 습관을 돌아보는 시간이 필요해요.','충동의 이유를 물어보기'],
 ['탑','⚡','다시 세우기','계획이 흔들려도 새 기준을 만들 수 있어요.','작은 대안 하나 세우기'],
 ['별','✶','회복과 희망','작은 진전에도 의미가 있음을 잊지 마세요.','내가 해낸 일 기억하기'],
 ['달','☽','감정과 불확실함','확신이 없어도 천천히 생각해 보는 것은 괜찮아요.','추측과 사실 나눠 적기'],
 ['태양','☼','생기와 명료함','평범한 하루의 기쁨을 알아차려 보세요.','기분 좋은 일정 만들기'],
 ['심판','♢','되돌아봄','배운 것을 정리하면 다음 선택이 쉬워질 수 있어요.','이전 경험의 교훈 정리하기'],
 ['세계','◎','완성과 시작','지금까지의 성장을 돌아보고 다음 걸음을 준비해 보세요.','작은 성과 기록하기']
];
const MINOR_SUITS=[
 {key:'wands',name:'완드',symbol:'♧',energy:'열정과 행동',hint:'열정을 어떻게 실천할지 살펴보세요.'},
 {key:'cups',name:'컵',symbol:'♜',energy:'감정과 관계',hint:'마음과 관계의 균형을 돌아보세요.'},
 {key:'swords',name:'소드',symbol:'⚔',energy:'생각과 결정',hint:'생각을 정리해 판단을 도와보세요.'},
 {key:'pentacles',name:'펜타클',symbol:'✥',energy:'일상과 자원',hint:'작은 습관과 현실의 자원을 살펴보세요.'}
];
const MINOR_RANKS=['에이스','2','3','4','5','6','7','8','9','10','시종','기사','여왕','왕'];
const MINOR_SIGNIFICANCE=[
 ['씨앗','시작할 수 있는 작은 기회가 보여요.'],['선택','두 가지 선택 사이에서 내 기준을 세워보세요.'],['협력','혼자보다 함께하는 방법을 생각해 보세요.'],['기반','지금까지 쌓은 안정적인 부분을 돌아보세요.'],['변화','흔들릴 때 나에게 필요한 지원을 찾아보세요.'],['나눔','주고받는 과정에서 배울 점을 살펴보세요.'],['점검','잠깐 멈추고 목표를 재확인해 보세요.'],['전진','빠르지 않아도 꾸준히 움직일 수 있어요.'],['집중','나를 지탱하는 기준과 에너지를 생각해 보세요.'],['정리','한 단계를 마무리할 준비를 해보세요.'],['탐색','새로운 배움을 열린 마음으로 살펴보세요.'],['움직임','행동에 옮기되 속도를 조절해 보세요.'],['배려','단단함과 다정함을 함께 활용해 보세요.'],['책임','내가 감당할 수 있는 범위를 정해보세요.']
];
const TAROT_FULL_DECK=[...MAJOR_ARCANA.map((a,i)=>({id:i,kind:'major',title:a[0],symbol:a[1],keyword:a[2],meaning:a[3],action:a[4],roman:['0','Ⅰ','Ⅱ','Ⅲ','Ⅳ','Ⅴ','Ⅵ','Ⅶ','Ⅷ','Ⅸ','Ⅹ','Ⅺ','Ⅻ','ⅩⅢ','ⅩⅣ','ⅩⅤ','ⅩⅥ','ⅩⅦ','ⅩⅧ','ⅩⅨ','ⅩⅩ','ⅩⅪ'][i]})),
 ...MINOR_SUITS.flatMap((s,si)=>MINOR_RANKS.map((rank,ri)=>({id:22+si*14+ri,kind:s.key,title:`${s.name} ${rank}`,symbol:s.symbol,keyword:`${s.energy} · ${MINOR_SIGNIFICANCE[ri][0]}`,meaning:`${s.energy}에 관한 카드예요. ${MINOR_SIGNIFICANCE[ri][1]}`,action:s.hint,roman:rank})))];
const TAROT_TOPICS={general:'종합운',love:'관계운',work:'일·금전운'};
const TAROT_POSITIONS={1:['오늘의 메시지'],3:['지금의 흐름','생각할 점','앞으로의 방향'],5:['현재','장애물','숨은 기회','실천할 일','정리할 방향']};
const tarotState={topic:'general',count:1,deck:[],selected:[],page:0};
function shuffleDeck(){
 const deck=Array.from({length:78},(_,i)=>i);
 for(let i=deck.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[deck[i],deck[j]]=[deck[j],deck[i]];}
 tarotState.deck=deck;tarotState.selected=[];tarotState.page=0;renderTarot();
}
function tarotMiniCard(slot){
 const id=tarotState.deck[slot],card=TAROT_FULL_DECK[id],selected=tarotState.selected.includes(id);
 return `<span class="tarot-preview-card ${selected?'picked':''}" aria-hidden="true">${selected?card.symbol:'✦'}</span>`;
}
function tarotTableCard(id,slot){
 const card=TAROT_FULL_DECK[id],selected=tarotState.selected.includes(id),all=tarotState.selected.length===tarotState.count;
 return `<button type="button" class="tarot-small-card ${selected?'picked':''}" data-tarot-slot="${slot}" aria-label="${selected?'선택한 '+card.title:'뒤집힌 카드 '+(slot+1)}" ${selected||all?'disabled':''} title="${selected?card.title:'카드를 선택하세요'}"><span class="tarot-small-ornament">${selected?card.symbol:'✦'}</span></button>`;
}
function renderTarot(){
 document.querySelectorAll('[data-tarot-topic]').forEach(b=>{const sel=b.dataset.tarotTopic===tarotState.topic;b.classList.toggle('selected',sel);b.setAttribute('aria-pressed',String(sel));});
 document.querySelectorAll('[data-tarot-count]').forEach(b=>{const sel=Number(b.dataset.tarotCount)===tarotState.count;b.classList.toggle('selected',sel);b.setAttribute('aria-pressed',String(sel));});
 const all=tarotState.selected.length===tarotState.count;
 $('tarotProgress').textContent=`${tarotState.selected.length} / ${tarotState.count}장`;
 $('tarotFullProgress').textContent=`${tarotState.selected.length} / ${tarotState.count}장`;
 $('tarotDeckCounter').textContent='78장 한 화면 선택';
 $('tarotInstruction').textContent=all?'카드 선택이 끝났어요. 결과를 확인해 보세요.':`원하는 ${tarotState.count}장을 한 화면에서 고를 수 있어요.`;
 $('tarotCards').innerHTML=Array.from({length:9},(_,i)=>tarotMiniCard(i)).join('');
 $('tarotTableCards').innerHTML=tarotState.deck.map((id,i)=>tarotTableCard(id,i)).join('');
 const cardNames=tarotState.selected.map(id=>TAROT_FULL_DECK[id].title);
 $('tarotTablePicks').textContent=cardNames.length?`선택: ${cardNames.join(' · ')}`:'카드를 선택해 주세요';
 $('tarotTableRead').disabled=!cardNames.length;
 $('tarotTableRead').textContent=all?'선택 완료 · 카드 해석 보기':`카드 해석 보기 (${tarotState.selected.length}장 선택)`;
 if(!cardNames.length){$('tarotReading').innerHTML='<p class="tarot-hint">78장 카드 중 한 화면에서 골라보세요. 카드 해석은 선택 후에 표시돼요.</p>';return;}
 const readings=tarotState.selected.map((id,i)=>{
   const c=TAROT_FULL_DECK[id];return `<article class="mystic-reading-card"><div class="mystic-reading-symbol">${c.symbol}</div><div><span class="mystic-reading-position">${TAROT_POSITIONS[tarotState.count][i]}</span><h3>${c.title}</h3><small>${c.keyword}</small><p>${c.meaning}</p><div class="mystic-reading-action"><b>작은 실천</b> ${c.action}</div></div></article>`;
 }).join('');
 $('tarotReading').innerHTML=`<div class="tarot-reading-intro"><span>✦ THE READING ✦</span><strong>선택한 카드의 이야기</strong><small>카드를 누른 순서로 메시지를 읽어보세요.</small></div><div class="mystic-readings-title">${TAROT_TOPICS[tarotState.topic]} 리딩 <small>${tarotState.selected.length}장</small></div>${readings}${all?'<p class="tarot-finished">✧ 타로는 미래의 결과를 보장하지 않는 상징적 해석이에요. 선택한 카드에서 지금 내게 필요한 생각 하나만 가져가 보세요.</p>':''}`;
}
function revealTarotCard(slot){
 if(!Number.isInteger(slot)||slot<0||slot>=78||tarotState.selected.length>=tarotState.count)return;
 const id=tarotState.deck[slot];if(tarotState.selected.includes(id))return;
 tarotState.selected.push(id);renderTarot();
}
function openTarotTable(){
 const overlay=$('tarotTableOverlay');overlay.classList.remove('hidden');overlay.setAttribute('aria-hidden','false');
 document.body.classList.add('tarot-table-open');$('tarotTableClose').focus();
}
function closeTarotTable(){
 const overlay=$('tarotTableOverlay');overlay.classList.add('hidden');overlay.setAttribute('aria-hidden','true');
 document.body.classList.remove('tarot-table-open');$('tarotOpenTable').focus();
}
function renderAll(){renderHome();renderCore();renderStats();renderProbability();renderPatternToggles();renderGenerator();renderSaved();renderDataStatus();renderSyncStatus();}
function gotoView(id){state.activeView=id;document.querySelectorAll('.view').forEach(v=>v.classList.toggle('active',v.id===id));document.querySelectorAll('[data-view]').forEach(b=>{b.classList.toggle('active',b.dataset.view===id);if(b.dataset.view===id)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');});scrollTo({top:0,behavior:'instant'});if(id==='saved')renderSaved();if(id==='generator'&&!state.generated.length&&!state.busy){runGenerator();}}
let delayedInstall=null;
window.addEventListener('beforeinstallprompt',event=>{event.preventDefault();delayedInstall=event;$('installBtn').textContent='앱으로 설치하기';});
if(window.LottoAndroid){$('installBtn').textContent='안드로이드 앱 설치 완료';$('installBtn').disabled=true;$('installHint').textContent='이미 APK로 설치되어 있어요. 앱 업데이트는 새 APK를 설치하면 됩니다.';}
$('installBtn').addEventListener('click',async()=>{if(delayedInstall){delayedInstall.prompt();await delayedInstall.userChoice;delayedInstall=null;}else toast('Chrome 또는 Safari 브라우저의 홈 화면에 추가 메뉴를 이용하세요.');});
$('openHelp').addEventListener('click',()=>{renderDataStatus();$('helpDialog').showModal();});
$('closeHelp').addEventListener('click',()=>$('helpDialog').close());
$('helpDialog').addEventListener('click',e=>{if(e.target===$('helpDialog'))$('helpDialog').close();});
$('refreshData').addEventListener('click',()=>refreshData());
$('importData').addEventListener('change',e=>{importDataFile(e.target.files?.[0]);e.target.value='';});
document.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',()=>gotoView(b.dataset.view)));
document.querySelectorAll('[data-goto]').forEach(b=>b.addEventListener('click',()=>gotoView(b.dataset.goto)));
$('statsRange').addEventListener('change',renderStats);
$('probRange').addEventListener('change',renderProbability);
document.querySelectorAll('[data-prob-range]').forEach(b=>b.addEventListener('click',()=>{$('probRange').value=b.dataset.probRange;document.querySelectorAll('[data-prob-range]').forEach(x=>x.classList.toggle('selected',x===b));renderProbability();}));
document.querySelectorAll('[data-fate-tab]').forEach(b=>b.addEventListener('click',()=>gotoFateTab(b.dataset.fateTab)));
$('sajuForm').addEventListener('submit',e=>{e.preventDefault();renderSajuResults();});
$('sajuTimeUnknown').addEventListener('change',e=>{$('sajuBirthTime').disabled=e.target.checked;});
$('sajuClear').addEventListener('click',()=>{$('sajuForm').reset();$('sajuBirthDate').value='';$('sajuBirthTime').value='12:00';$('sajuReadDate').value=fmtYmd(kstDateParts());$('sajuBirthTime').disabled=false;$('sajuResult').innerHTML='<div class="saju-empty">입력 정보를 지웠어요. 생일을 입력하면 간이 사주운세를 볼 수 있어요.</div>';try{localStorage.removeItem(FATE_PROFILE_KEY);}catch(_){};});
$('tarotOpenTable').addEventListener('click',openTarotTable);
$('tarotTableClose').addEventListener('click',closeTarotTable);
$('tarotTableRead').addEventListener('click',()=>{closeTarotTable();$('tarotReading').scrollIntoView({behavior:'smooth',block:'start'});});
$('tarotTableShuffle').addEventListener('click',shuffleDeck);
$('tarotTableCards').addEventListener('click',e=>{const b=e.target.closest('[data-tarot-slot]');if(b)revealTarotCard(Number(b.dataset.tarotSlot));});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('tarotTableOverlay').classList.contains('hidden'))closeTarotTable();});
$('tarotReset').addEventListener('click',shuffleDeck);
document.querySelectorAll('[data-tarot-topic]').forEach(b=>b.addEventListener('click',()=>{tarotState.topic=b.dataset.tarotTopic;shuffleDeck();}));
document.querySelectorAll('[data-tarot-count]').forEach(b=>b.addEventListener('click',()=>{tarotState.count=Number(b.dataset.tarotCount);shuffleDeck();}));
$('generateBtn').addEventListener('click',runGenerator);
$('generatorOptions').addEventListener('change',e=>{
 const key=e.target?.dataset?.pattern;
 if(key && Object.hasOwn(defaultPatternToggles,key)){
  state.patterns[key]=!!e.target.checked;persistPatterns();
 }else if(e.target?.id==='coreMode')markGenerationDirty();
});
$('generatorOptions').addEventListener('click',e=>{
 const action=e.target.closest('[data-pattern-action]')?.dataset.patternAction;
 if(!action)return;
 if(action==='all')for(const key of Object.keys(defaultPatternToggles))state.patterns[key]=true;
 if(action==='none')for(const key of Object.keys(defaultPatternToggles))state.patterns[key]=false;
 if(action==='reset')state.patterns={...defaultPatternToggles};
 persistPatterns();
});
for(const id of ['candidateCount','pickCount','genMode','maxOverlap'])$(id).addEventListener('change',markGenerationDirty);
$('toggleWeights').addEventListener('click',()=>{const panel=$('weightPanel');panel.hidden=!panel.hidden;$('toggleWeights').textContent=panel.hidden?'가중치 보기 ↓':'가중치 닫기 ↑';$('toggleWeights').setAttribute('aria-expanded',String(!panel.hidden));});
$('weightInputs').addEventListener('change',e=>{let key=e.target.dataset.weight;if(key&&Object.hasOwn(defaults,key)){let v=Number(e.target.value);if(!Number.isFinite(v)||v<0||v>30){toast('점수는 0~30 사이로 입력해 주세요.');renderWeights();return;}state.weights[key]=v;writeStore(keys.weights,state.weights);renderWeights();markGenerationDirty();toast('점수표가 저장됐어요');}});
$('resetWeights').addEventListener('click',()=>{state.weights={...defaults};writeStore(keys.weights,state.weights);renderWeights();markGenerationDirty();toast('기본 점수로 초기화했어요');});
$('generatedResults').addEventListener('change',e=>{
 const b=e.target;if(b.id==='selectAllGenerated'){state.selectedGenerated=b.checked?new Set(state.generated.map((_,i)=>i)):new Set();renderGenerator();return;}
 if(b.matches('[data-select-pick]')){const i=Number(b.dataset.selectPick);if(b.checked)state.selectedGenerated.add(i);else state.selectedGenerated.delete(i);renderGenerator();}
});
$('generatedResults').addEventListener('click',e=>{
 if(e.target.closest('#saveSelected')){let added=0;for(const i of state.selectedGenerated){const p=state.generated[i];if(p&&saveTicket(p.nums))added++;}persistSaved();toast(added?`${added}개 선택 조합을 저장했어요`:'저장할 새 조합을 체크해 주세요');return;}

 const save=e.target.closest('[data-save-pick]');if(save){const idx=Number(save.dataset.savePick);if(state.generated[idx]){toast(saveTicket(state.generated[idx].nums)?'보관함에 저장했어요':'이미 저장한 번호예요');persistSaved();}return;}
 if(e.target.closest('#copyGenerated'))copyText(state.generated.map(x=>numsText(x.nums)).join('\n'));
 if(e.target.closest('#saveGenerated')){let added=0;for(const p of state.generated)if(saveTicket(p.nums))added++;persistSaved();toast(`${added}조합을 보관함에 저장했어요`);}
 if(e.target.closest('#exportGenerated'))downloadFile('LOTTO_LAB_추천번호.csv','번호1,번호2,번호3,번호4,번호5,번호6,패턴점수\n'+state.generated.map(p=>[...p.nums,p.rating.percent].join(',')).join('\n'));
});
$('addManual').addEventListener('click',()=>{let s=$('manualNumbers').value.trim(),arr=s.split(/[\s,;/]+/).filter(Boolean).map(Number);if(arr.length!==6||arr.some(x=>!Number.isInteger(x)||x<1||x>45)||new Set(arr).size!==6){toast('1~45 사이 중복 없는 번호 6개를 입력해 주세요');return;}if(saveTicket(arr)){persistSaved();$('manualNumbers').value='';toast('내 번호가 저장됐어요');}else toast('이미 저장한 번호예요');});
$('savedResults').addEventListener('click',e=>{const b=e.target.closest('[data-delete]');if(b){state.saved=state.saved.filter(x=>x.id!==b.dataset.delete);persistSaved();toast('저장한 번호를 삭제했어요');}});
$('checkRound').addEventListener('change',renderSaved);
$('importSaved').addEventListener('change',async e=>{const f=e.target.files?.[0];e.target.value='';if(!f)return;
 try{const lines=(await f.text()).replace(/^\uFEFF/,'').trim().split(/\r?\n/);let added=0;
  for(const line of lines.slice(1)){const cols=line.split(',').map(s=>s.trim());if(cols.length<7)continue;const round=Number(cols[0]),nums=cols.slice(1,7).map(Number);
    if(!Number.isInteger(round)||round<1||nums.length!==6||nums.some(n=>!Number.isInteger(n)||n<1||n>45)||new Set(nums).size!==6)continue;
    nums.sort((a,b)=>a-b);const key=`${round}-${nums.join('-')}`;if(state.saved.some(v=>v.key===key))continue;
    state.saved.push({id:Date.now().toString(36)+Math.random().toString(36).slice(2,7),key,nums,targetRound:round});added++;
  }persistSaved();toast(`${added}개 번호를 복원했어요`);
 }catch(err){toast('번호 복원 실패: '+err.message);}
});
$('exportSaved').addEventListener('click',()=>{if(!state.saved.length){toast('저장한 번호가 없어요');return;}downloadFile('LOTTO_LAB_내번호.csv','대상회차,번호1,번호2,번호3,번호4,번호5,번호6\n'+state.saved.map(p=>[p.targetRound,...p.nums].join(',')).join('\n'));});
initSaju();
shuffleDeck();
renderAll();
// Refresh while the app is open (also when returning from background). Does not run as an Android background service.
if(location.protocol==='https:'||location.hostname==='localhost'||location.hostname==='127.0.0.1'){
 if('serviceWorker' in navigator && location.hostname!=='appassets.androidplatform.net')navigator.serviceWorker.register('sw.js').catch(()=>{});
 setTimeout(refreshIfDue,700);
 window.addEventListener('online',refreshIfDue);
 document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')refreshIfDue();});
 window.addEventListener('focus',refreshIfDue);
 setInterval(()=>{if(document.visibilityState==='visible')refreshIfDue();},60*60*1000);
}
// Expose a tiny read-only test API for integration tests.
window.LottoLab={getData:()=>state.rows.map(x=>({...x,numbers:x.numbers.slice()})),score:(numbers)=>scoreCombo(numbers,buildContext(state.rows)),grade:(numbers,draw)=>gradeTicket(numbers,draw||latest()),generate:()=>runGenerator(),hasWholeHistory:haveWholeHistory,refresh:()=>refreshData(),onResume:refreshIfDue,weeklyCore:()=>weeklyCore(state.rows),tarotSnapshot:()=>({topic:tarotState.topic,count:tarotState.count,selected:tarotState.selected.slice(),deck:tarotState.deck.slice(),page:tarotState.page}),sajuPillars:approximatePillars,tarotDeckSize:()=>TAROT_FULL_DECK.length,theoreticalProbabilities:()=>({...baseTheoretical}),patternProbability:()=>probSampleEvents(state.rows,$('probRange').value),testGrade:gradeTicket,activePatternOptions,patterns:()=>({...state.patterns}),setPattern:(name,enabled)=>{if(!Object.hasOwn(defaultPatternToggles,name))return false;state.patterns[name]=!!enabled;persistPatterns();return true;}};
})();
