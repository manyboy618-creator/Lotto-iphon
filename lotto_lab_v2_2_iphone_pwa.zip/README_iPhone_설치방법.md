# iPhone (Safari)에서 LOTTO LAB 설치하기

1. 이 폴더의 **내용물** (`index.html`, `app.js`, `styles.css`, `manifest.webmanifest`, `assets/` 등)을 GitHub Pages용 저장소 최상위에 업로드합니다. ZIP 1개만 업로드해도 GitHub Pages가 자동으로 압축을 풀어 주지는 않아요.
2. 저장소 Settings > Pages > Build and deployment > Deploy from a branch > main / (root) > Save.
3. 게시된 https://계정.github.io/저장소/ 주소를 iPhone Safari에서 엽니다.
4. 공유 메뉴 > 홈 화면에 추가 > '웹 앱으로 열기' 활성화 > 추가.

참고: GitHub Pages는 해당 게시 웹사이트를 공개적으로 제공하므로 소스코드와 비공개 자료를 올리지 마세요. 로또 저장번호는 기기 브라우저에 저장되고 Android의 보관함과 동기화되지 않습니다. CSV로 내보내기/불러오기를 사용하세요.

앱스토어에 정식 iOS 앱을 올리려면 별도 iOS 프로젝트, macOS/Xcode 빌드 및 Apple 개발자 서명과 심사가 필요합니다.
